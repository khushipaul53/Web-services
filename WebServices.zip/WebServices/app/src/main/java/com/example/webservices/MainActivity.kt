package com.example.webservices

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import kotlinx.android.synthetic.main.activity_main.*
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btnShowTime.setOnClickListener { view ->
//            Toast.makeText(this, "click", Toast.LENGTH_SHORT).show();

            val service= Retrofit.Builder()
                    .baseUrl("https://randomuser.me/")
                    .addConverterFactory(MoshiConverterFactory.create())
                    .build()
                    .create(CityService::class.java)

            service.getTime().enqueue(object : Callback<CityResponse> {
                override fun onResponse(call: retrofit2.Call<CityResponse>, response: Response<CityResponse>) {
                    /* This will print the response of the network call to the Logcat */
                    Log.d("TAG_", response.body().toString())
                    if(response.isSuccessful)
                    {
                        tvSunsetTime.setText("Email: "+response.body()?.results?.get(0)?.email+"\n"+"PhoneNumber: "+response.body()?.results?.get(0)?.phone)
                    }



                }

                override fun onFailure(call: retrofit2.Call<CityResponse>, t: Throwable) {
                    //            Toast.makeText(this, "api fat gyi....", Toast.LENGTH_SHORT).show();

                }
            })


        }




    }
    data class CityResponse(val results: List<User>)
    data class User(val email: String, val phone: String)

    interface CityService {
        @GET("/api")
        fun getTime(): retrofit2.Call<CityResponse>
    }
    }
